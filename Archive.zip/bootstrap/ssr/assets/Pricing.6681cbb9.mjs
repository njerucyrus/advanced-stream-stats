import { mergeProps, unref, withCtx, createTextVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderStyle, ssrInterpolate, ssrRenderComponent } from "vue/server-renderer";
import "./AuthenticatedLayout.5cdfa709.mjs";
import { Link } from "@inertiajs/inertia-vue3";
import { _ as _export_sfc } from "./ApplicationLogo.1930efc5.mjs";
const Pricing_vue_vue_type_style_index_0_scoped_ebac12cb_lang = "";
const _sfc_main = {
  __name: "Pricing",
  __ssrInlineRender: true,
  props: {
    "plans": Object
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "py-12" }, _attrs))} data-v-ebac12cb><div data-v-ebac12cb><div class="bg-white overflow-hidden shadow-sm sm:rounded-lg" data-v-ebac12cb><div class="m-8" data-v-ebac12cb><p data-v-ebac12cb>Welcome to advanced stream stats.This app helps you to get all your twitch video stream statistics in real time </p></div><div data-v-ebac12cb><div class="container my-24 px-6 mx-auto" data-v-ebac12cb><section class="mb-32 text-gray-800" data-v-ebac12cb><div id="pricing-block-5" class="background-radial-gradient text-center text-white" data-v-ebac12cb><h2 class="text-3xl font-bold text-center mb-32" data-v-ebac12cb>Pricing</h2></div><div class="grid lg:grid-cols-3 px-6 md:px-12 xl:px-32" style="${ssrRenderStyle({ "margin-top": "-200px" })}" data-v-ebac12cb><div class="p-0 m-1 py-12" data-v-ebac12cb><div class="block rounded-lg shadow-lg bg-white h-full lg:rounded-tr-none lg:rounded-br-none" data-v-ebac12cb><div class="p-6 border-b border-gray-300 text-center" data-v-ebac12cb><p class="uppercase mb-4 text-sm" data-v-ebac12cb><strong data-v-ebac12cb>${ssrInterpolate(__props.plans[1].name)}</strong></p><h3 class="text-2xl mb-6" data-v-ebac12cb><strong data-v-ebac12cb>$ ${ssrInterpolate(__props.plans[1].price)}</strong><small class="text-gray-500 text-sm" data-v-ebac12cb>/month</small></h3>`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("show_checkout_form", { planId: __props.plans[1].id }),
        class: "inline-block px-6 py-2.5 bg-orange-500 text-white font-medium text-xs leading-tight uppercase rounded shadow-md hover:bg-orange-700 hover:shadow-lg focus:bg-orange-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-orange-700 active:shadow-lg transition duration-150 ease-in-out w-full",
        "data-mdb-ripple": "true",
        "data-ripple-color": "orange"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Buy `);
          } else {
            return [
              createTextVNode(" Buy ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="p-6" data-v-ebac12cb><ol class="list-inside" data-v-ebac12cb><li class="mb-4 flex items-center" data-v-ebac12cb><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="check" class="text-green-600 w-4 h-4 mr-2" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-v-ebac12cb><path fill="currentColor" d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z" data-v-ebac12cb></path></svg>10 Reports </li><li class="mb-4 flex items-center" data-v-ebac12cb><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="check" class="text-green-600 w-4 h-4 mr-2" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-v-ebac12cb><path fill="currentColor" d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z" data-v-ebac12cb></path></svg>Export report to csv </li><li class="mb-4 flex items-center" data-v-ebac12cb><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="check" class="text-green-600 w-4 h-4 mr-2" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-v-ebac12cb><path fill="currentColor" d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z" data-v-ebac12cb></path></svg> Get current month statistics </li></ol></div></div></div><div class="p-0 m-1" data-v-ebac12cb><div class="block rounded-lg shadow-lg bg-white h-full z-10" data-v-ebac12cb><div class="p-6 border-b border-gray-300 text-center" data-v-ebac12cb><p class="uppercase mb-4 text-sm" data-v-ebac12cb><strong data-v-ebac12cb>${ssrInterpolate(__props.plans[2].name)}</strong></p><h3 class="text-2xl mb-6" data-v-ebac12cb><strong data-v-ebac12cb>$ ${ssrInterpolate(__props.plans[2].price)}</strong><small class="text-gray-500 text-sm" data-v-ebac12cb>/year</small></h3>`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("show_checkout_form", { "planId": __props.plans[2].id }),
        class: "no-underline inline-block px-6 py-2.5 bg-blue-600 text-white font-medium text-xs leading-tight uppercase rounded shadow-md hover:bg-blue-700 hover:shadow-lg focus:bg-blue-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out w-full"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Buy `);
          } else {
            return [
              createTextVNode(" Buy ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="p-6" data-v-ebac12cb><ol class="list-inside" data-v-ebac12cb><li class="mb-4 flex items-center" data-v-ebac12cb><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="check" class="text-green-600 w-4 h-4 mr-2" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-v-ebac12cb><path fill="currentColor" d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z" data-v-ebac12cb></path></svg>Unlimited reports </li><li class="mb-4 flex items-center" data-v-ebac12cb><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="check" class="text-green-600 w-4 h-4 mr-2" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-v-ebac12cb><path fill="currentColor" d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z" data-v-ebac12cb></path></svg>Export report to excel </li><li class="mb-4 flex items-center" data-v-ebac12cb><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="check" class="text-green-600 w-4 h-4 mr-2" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-v-ebac12cb><path fill="currentColor" d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z" data-v-ebac12cb></path></svg>Export report to pdf </li><li class="mb-4 flex items-center" data-v-ebac12cb><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="check" class="text-green-600 w-4 h-4 mr-2" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-v-ebac12cb><path fill="currentColor" d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z" data-v-ebac12cb></path></svg>Export report to csv </li><li class="mb-4 flex items-center" data-v-ebac12cb><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="check" class="text-green-600 w-4 h-4 mr-2" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-v-ebac12cb><path fill="currentColor" d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z" data-v-ebac12cb></path></svg>Get custom date range reporting </li><li class="mb-4 flex items-center" data-v-ebac12cb><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="check" class="text-green-600 w-4 h-4 mr-2" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-v-ebac12cb><path fill="currentColor" d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z" data-v-ebac12cb></path></svg>Premium support </li><li class="mb-4 flex items-center" data-v-ebac12cb><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="check" class="text-green-600 w-4 h-4 mr-2" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-v-ebac12cb><path fill="currentColor" d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z" data-v-ebac12cb></path></svg>Get ranking analytics </li></ol></div></div></div><div class="p-0 m-1 py-10" data-v-ebac12cb><div class="block rounded-lg shadow-lg bg-white h-full lg:rounded-tl-none lg:rounded-bl-none" data-v-ebac12cb><div class="p-6 border-b border-gray-300 text-center" data-v-ebac12cb><p class="uppercase mb-4 text-sm" data-v-ebac12cb><strong data-v-ebac12cb>${ssrInterpolate(__props.plans[0].name)}</strong></p><h3 class="text-2xl mb-6" data-v-ebac12cb><strong data-v-ebac12cb>$ ${ssrInterpolate(__props.plans[0].price)}</strong><small class="text-gray-500 text-sm" data-v-ebac12cb>/year</small></h3>`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("show_checkout_form", { "planId": __props.plans[0].id }),
        class: "text-white inline-block px-6 py-2.5 bg-green-500 text-blue-600 font-medium text-xs leading-tight uppercase rounded hover:text-white-700 hover:bg-green-700 focus:bg-green-700 focus:outline-none focus:ring-0 active:bg-green-700 transition duration-150 ease-in-out w-full"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Buy `);
          } else {
            return [
              createTextVNode(" Buy ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="p-6" data-v-ebac12cb><ol class="list-inside" data-v-ebac12cb><li class="mb-4 flex items-center" data-v-ebac12cb><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="check" class="text-green-600 w-4 h-4 mr-2" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-v-ebac12cb><path fill="currentColor" d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z" data-v-ebac12cb></path></svg>All features in enterprise </li><li class="mb-4 flex items-center" data-v-ebac12cb><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="check" class="text-green-600 w-4 h-4 mr-2" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-v-ebac12cb><path fill="currentColor" d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z" data-v-ebac12cb></path></svg>Custom branding on the reports </li><li class="mb-4 flex items-center" data-v-ebac12cb><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="check" class="text-green-600 w-4 h-4 mr-2" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-v-ebac12cb><path fill="currentColor" d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z" data-v-ebac12cb></path></svg>24/7 hr support </li><li class="mb-4 flex items-center" data-v-ebac12cb><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="check" class="text-green-600 w-4 h-4 mr-2" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-v-ebac12cb><path fill="currentColor" d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z" data-v-ebac12cb></path></svg>Forecast insights </li></ol></div></div></div></div></section></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Pricing.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Pricing = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-ebac12cb"]]);
export {
  Pricing as default
};
